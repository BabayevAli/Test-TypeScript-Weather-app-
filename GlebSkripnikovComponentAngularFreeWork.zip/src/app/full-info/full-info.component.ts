import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-full-info',
  templateUrl: './full-info.component.html',
  styleUrls: ['./full-info.component.css']
})
export class FullInfoComponent implements OnInit {

  apiUrl: string = '';
  apiKey: string = '';

  constructor() { }

    
  ngOnInit() {
  
  }


}
