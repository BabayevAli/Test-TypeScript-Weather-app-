import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-days-info',
  templateUrl: './days-info.component.html',
  styleUrls: ['./days-info.component.css']
})
export class DaysInfoComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
